const notFound = (req, res) =>
  res.status(404).json({ message: `Route not found: ${req.method} ${req.originalUrl}` });

// Central error handler: always responds with { message, errors? }
const errorHandler = (err, req, res, next) => {
  // Mongoose validation errors -> 400 with per-field messages
  if (err.name === "ValidationError") {
    const errors = {};
    Object.values(err.errors).forEach((e) => (errors[e.path] = e.message));
    return res.status(400).json({ message: "Validation failed", errors });
  }
  // Duplicate key (unique email) -> 409
  if (err.code === 11000) {
    return res.status(409).json({
      message: "A contact with this email already exists",
      errors: { email: "This email is already in use" },
    });
  }
  // Bad JSON body
  if (err.type === "entity.parse.failed") {
    return res.status(400).json({ message: "Invalid JSON in request body" });
  }
  console.error(err);
  res.status(500).json({ message: "Something went wrong on the server" });
};

module.exports = { notFound, errorHandler };
