const express = require("express");
const mongoose = require("mongoose");
const Contact = require("../models/Contact");

const router = express.Router();
const FIELDS = ["name", "email", "phone", "company", "notes"];

// Only allow known fields (prevents mass-assignment of unexpected keys)
const pick = (body) =>
  FIELDS.reduce((acc, f) => {
    if (body[f] !== undefined) acc[f] = body[f];
    return acc;
  }, {});

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

// Reject malformed ids early
const validateId = (req, res, next) => {
  if (!mongoose.isValidObjectId(req.params.id)) {
    return res.status(400).json({ message: "Invalid contact id" });
  }
  next();
};

// CREATE
router.post("/", async (req, res, next) => {
  try {
    const contact = await Contact.create(pick(req.body));
    res.status(201).json(contact);
  } catch (err) {
    next(err);
  }
});

// READ all (optional ?search=)
router.get("/", async (req, res, next) => {
  try {
    const { search } = req.query;
    const filter = {};
    if (search && String(search).trim()) {
      const rx = new RegExp(escapeRegex(String(search).trim()), "i");
      filter.$or = [{ name: rx }, { email: rx }, { phone: rx }, { company: rx }];
    }
    const contacts = await Contact.find(filter).sort({ name: 1 });
    res.json(contacts);
  } catch (err) {
    next(err);
  }
});

// READ one
router.get("/:id", validateId, async (req, res, next) => {
  try {
    const contact = await Contact.findById(req.params.id);
    if (!contact) return res.status(404).json({ message: "Contact not found" });
    res.json(contact);
  } catch (err) {
    next(err);
  }
});

// UPDATE
router.put("/:id", validateId, async (req, res, next) => {
  try {
    const contact = await Contact.findByIdAndUpdate(req.params.id, pick(req.body), {
      new: true,
      runValidators: true,
    });
    if (!contact) return res.status(404).json({ message: "Contact not found" });
    res.json(contact);
  } catch (err) {
    next(err);
  }
});

// DELETE
router.delete("/:id", validateId, async (req, res, next) => {
  try {
    const contact = await Contact.findByIdAndDelete(req.params.id);
    if (!contact) return res.status(404).json({ message: "Contact not found" });
    res.json({ message: "Contact deleted", id: contact._id });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
