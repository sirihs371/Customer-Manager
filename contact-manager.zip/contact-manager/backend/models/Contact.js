const mongoose = require("mongoose");

const contactSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Name is required"],
      trim: true,
      minlength: [2, "Name must be at least 2 characters"],
      maxlength: [80, "Name must be 80 characters or fewer"],
    },
    email: {
      type: String,
      required: [true, "Email is required"],
      trim: true,
      lowercase: true,
      unique: true,
      match: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, "Enter a valid email address"],
    },
    phone: {
      type: String,
      trim: true,
      default: "",
      match: [/^$|^[+()\-\s\d]{7,20}$/, "Enter a valid phone number (7–20 digits)"],
    },
    company: { type: String, trim: true, default: "", maxlength: 80 },
    notes: { type: String, trim: true, default: "", maxlength: 500 },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Contact", contactSchema);
