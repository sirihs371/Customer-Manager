const BASE = "/api/contacts";

// Throws an Error carrying { status, fieldErrors } for the UI to display
async function request(url = "", options = {}) {
  let res;
  try {
    res = await fetch(BASE + url, {
      headers: { "Content-Type": "application/json" },
      ...options,
    });
  } catch {
    throw Object.assign(new Error("Cannot reach the server. Is the backend running?"), {
      fieldErrors: {},
    });
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw Object.assign(new Error(data.message || "Request failed"), {
      status: res.status,
      fieldErrors: data.errors || {},
    });
  }
  return data;
}

export const getContacts = (search = "") =>
  request(search ? `?search=${encodeURIComponent(search)}` : "");
export const createContact = (c) => request("", { method: "POST", body: JSON.stringify(c) });
export const updateContact = (id, c) =>
  request(`/${id}`, { method: "PUT", body: JSON.stringify(c) });
export const deleteContact = (id) => request(`/${id}`, { method: "DELETE" });
