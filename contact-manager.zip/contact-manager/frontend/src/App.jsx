import { useCallback, useEffect, useState } from "react";
import * as api from "./api";
import ContactForm from "./components/ContactForm.jsx";
import ContactList from "./components/ContactList.jsx";

export default function App() {
  const [contacts, setContacts] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState(null); // contact being edited
  const [toast, setToast] = useState("");

  const load = useCallback(async () => {
    try {
      setError("");
      setContacts(await api.getContacts(search));
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [search]);

  // Debounced search / initial load
  useEffect(() => {
    const t = setTimeout(load, 250);
    return () => clearTimeout(t);
  }, [load]);

  const flash = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(""), 2500);
  };

  // Called by the form; throws on failure so the form can show field errors
  const handleSave = async (data) => {
    if (editing) {
      await api.updateContact(editing._id, data);
      setEditing(null);
      flash("Contact updated");
    } else {
      await api.createContact(data);
      flash("Contact added");
    }
    await load();
  };

  const handleDelete = async (contact) => {
    if (!window.confirm(`Delete ${contact.name}? This can't be undone.`)) return;
    try {
      await api.deleteContact(contact._id);
      if (editing?._id === contact._id) setEditing(null);
      flash("Contact deleted");
      await load();
    } catch (e) {
      setError(e.message);
    }
  };

  return (
    <div className="shell">
      <header className="masthead">
        <h1>Contacts</h1>
        <p>{contacts.length} {contacts.length === 1 ? "person" : "people"}{search && " match your search"}</p>
      </header>

      <main className="layout">
        <section className="panel form-panel">
          <h2>{editing ? `Edit ${editing.name}` : "Add a contact"}</h2>
          <ContactForm
            key={editing?._id || "new"}
            initial={editing}
            onSave={handleSave}
            onCancel={() => setEditing(null)}
          />
        </section>

        <section className="panel list-panel">
          <input
            type="search"
            className="search"
            placeholder="Search by name, email, phone or company"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            aria-label="Search contacts"
          />
          {error && (
            <div className="alert" role="alert">
              {error} <button onClick={load}>Retry</button>
            </div>
          )}
          <ContactList
            contacts={contacts}
            loading={loading}
            searching={!!search}
            onEdit={setEditing}
            onDelete={handleDelete}
            activeId={editing?._id}
          />
        </section>
      </main>

      {toast && <div className="toast" role="status">{toast}</div>}
    </div>
  );
}
