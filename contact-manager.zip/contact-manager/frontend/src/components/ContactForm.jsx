import { useState } from "react";

const EMPTY = { name: "", email: "", phone: "", company: "", notes: "" };

// Mirrors the server-side rules so people get instant feedback
function validate(v) {
  const e = {};
  if (v.name.trim().length < 2) e.name = "Name must be at least 2 characters";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.email.trim())) e.email = "Enter a valid email address";
  if (v.phone && !/^[+()\-\s\d]{7,20}$/.test(v.phone.trim()))
    e.phone = "Enter a valid phone number (7–20 digits)";
  if (v.notes.length > 500) e.notes = "Notes must be 500 characters or fewer";
  return e;
}

export default function ContactForm({ initial, onSave, onCancel }) {
  const [values, setValues] = useState(
    initial
      ? Object.fromEntries(Object.keys(EMPTY).map((k) => [k, initial[k] || ""]))
      : EMPTY
  );
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState("");
  const [saving, setSaving] = useState(false);

  const change = (e) => {
    setValues({ ...values, [e.target.name]: e.target.value });
    if (errors[e.target.name]) setErrors({ ...errors, [e.target.name]: undefined });
  };

  const submit = async (e) => {
    e.preventDefault();
    setFormError("");
    const found = validate(values);
    setErrors(found);
    if (Object.keys(found).length) return;

    setSaving(true);
    try {
      await onSave(values);
      if (!initial) setValues(EMPTY);
    } catch (err) {
      setErrors(err.fieldErrors || {});
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const field = (name, label, props = {}) => (
    <div className={`field ${errors[name] ? "invalid" : ""}`}>
      <label htmlFor={name}>{label}</label>
      <input id={name} name={name} value={values[name]} onChange={change} {...props} />
      {errors[name] && <span className="msg">{errors[name]}</span>}
    </div>
  );

  return (
    <form onSubmit={submit} noValidate>
      {formError && <div className="alert" role="alert">{formError}</div>}
      {field("name", "Full name", { autoComplete: "name" })}
      {field("email", "Email", { type: "email", autoComplete: "email" })}
      {field("phone", "Phone (optional)", { type: "tel", autoComplete: "tel" })}
      {field("company", "Company (optional)")}
      <div className={`field ${errors.notes ? "invalid" : ""}`}>
        <label htmlFor="notes">Notes (optional)</label>
        <textarea id="notes" name="notes" rows="3" value={values.notes} onChange={change} />
        {errors.notes && <span className="msg">{errors.notes}</span>}
      </div>
      <div className="actions">
        <button className="primary" disabled={saving}>
          {saving ? "Saving…" : initial ? "Save changes" : "Add contact"}
        </button>
        {initial && (
          <button type="button" className="ghost" onClick={onCancel}>Cancel</button>
        )}
      </div>
    </form>
  );
}
