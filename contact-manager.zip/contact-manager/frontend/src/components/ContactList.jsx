export default function ContactList({ contacts, loading, searching, onEdit, onDelete, activeId }) {
  if (loading) return <p className="empty">Loading contacts…</p>;
  if (!contacts.length)
    return (
      <p className="empty">
        {searching ? "No contacts match that search." : "No contacts yet. Add your first one using the form."}
      </p>
    );

  return (
    <ul className="list">
      {contacts.map((c) => (
        <li key={c._id} className={c._id === activeId ? "active" : ""}>
          <div className="avatar" aria-hidden="true">{c.name.charAt(0).toUpperCase()}</div>
          <div className="info">
            <strong>{c.name}</strong>
            <a href={`mailto:${c.email}`}>{c.email}</a>
            {(c.phone || c.company) && (
              <span className="sub">{[c.company, c.phone].filter(Boolean).join(" · ")}</span>
            )}
            {c.notes && <span className="notes">{c.notes}</span>}
          </div>
          <div className="row-actions">
            <button className="ghost" onClick={() => onEdit(c)}>Edit</button>
            <button className="danger" onClick={() => onDelete(c)}>Delete</button>
          </div>
        </li>
      ))}
    </ul>
  );
}
