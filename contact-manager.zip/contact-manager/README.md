# Contact Manager (MERN)

React (Vite) frontend · Node.js/Express API · MongoDB (Mongoose)

## Prerequisites
- Node.js 18+
- MongoDB running locally (`mongodb://127.0.0.1:27017`) or a MongoDB Atlas connection string

## Setup

### 1. Backend
```bash
cd backend
npm install
cp .env.example .env      # edit MONGODB_URI if needed
npm run dev               # http://localhost:5000
```

### 2. Frontend (new terminal)
```bash
cd frontend
npm install
npm run dev               # http://localhost:5173
```
Vite proxies `/api` to the backend, so no extra config is needed.

## REST API
| Method | Endpoint             | Description                          |
|--------|----------------------|--------------------------------------|
| POST   | /api/contacts        | Create a contact                     |
| GET    | /api/contacts        | List contacts (`?search=term`)       |
| GET    | /api/contacts/:id    | Get one contact                      |
| PUT    | /api/contacts/:id    | Update a contact                     |
| DELETE | /api/contacts/:id    | Delete a contact                     |

Contact fields: `name` (required, 2–80), `email` (required, valid, unique),
`phone`, `company`, `notes` (all optional).

## Validation & errors
- Client-side: instant field messages in `ContactForm.jsx`.
- Server-side: Mongoose schema validators -> `400 { message, errors }`.
- Duplicate email -> `409`; invalid id -> `400`; missing contact -> `404`;
  unexpected failures -> `500`. Handled centrally in `middleware/errorHandler.js`.

## Production build
```bash
cd frontend && npm run build   # outputs frontend/dist
```
